<template>
  <div>About View</div>
</template>

<script>
export default {
  name: 'AboutView',
}
</script>
