# Changelog

## [1.3.0](https://www.github.com/14790897/handwriting-web/compare/v1.2.0...v1.3.0) (2023-12-31)


### Features

* feedback interface ([8ee7557](https://www.github.com/14790897/handwriting-web/commit/8ee7557dc32a7ec3320a9cd9956b8da599eb090b))
* pdf return ([79dea4d](https://www.github.com/14790897/handwriting-web/commit/79dea4dd7a97bc80854401baa3b9943af11bd49d))
* 下划线选择功能 ([e607e53](https://www.github.com/14790897/handwriting-web/commit/e607e534e653d7eb63ba28a221cf261d83be02b3))
* 用户在宽度高度确定时候点击选择图片文件会弹出提示 ([11ddca0](https://www.github.com/14790897/handwriting-web/commit/11ddca0f55881a270d1410b6e277379971e37f05))


### Bug Fixes

* prompt ([de47b42](https://www.github.com/14790897/handwriting-web/commit/de47b42e1d090669f7a12e17bd891e4321c2cd3d))
文档已移动到 docs/

请查看 `docs/frontend/CHANGELOG.md` 获取前端变更日志。
